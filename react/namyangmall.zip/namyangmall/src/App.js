import React from 'react';
import { Route, Link } from 'react-router-dom';
import './App.css';
import MainPage from './component/mainpage';
//서브컴포넌트
import Member from './component/member';
import Product from './component/product';
import Market from './component/market';
import Brand from './component/brand';
import Plan from './component/plan';
import Event from './component/event';
import Delivery from './component/delivery';
import {TextProvider} from './context';
import {FaHeadset} from 'react-icons/fa';
import {MdQuestionAnswer} from 'react-icons/md';
import {BsFacebook, BsInstagram, BsFillArrowRightCircleFill} from 'react-icons/bs'
import {AiFillTwitterCircle, AiFillYoutube} from 'react-icons/ai'
import {BiSearchAlt, BiShoppingBag, BiTime, BiSmile} from 'react-icons/bi'


//부트스트랩 설치
//yarn add react-bootstrap bootstrap
//index.js
//import 'bootstrap/dist/css/bootstrap.css'

//react-router-dom: 라우터 관련 함수를 내장
//설치: yarn add react-router-dom@5
//패키지 연결
//import { Route, Link } from 'react-router-dom'
//특정 주소에 컴포넌트 연결하는 방법
//<Route path="주소" component={보여줄 컴포넌트}></Route>
//index.js에서 설정하기
//import {BrowserRouter} from 'react-router-dom';
//<App/>앞뒤에 <BrowserRouter></BrowserRouter>로 감싸준다
// 배포용 파일 변환 yarn build 실행 -> build폴더 생성

// 리액트 아이콘 설치
// yarn add react-icons



function App() {
  return (
    <div>
      <TextProvider>
      <div className='wrap'>
       <div className='headermini'>
          <div className='headerminiin'>
            <p>로그인</p>
            <p>회원가입</p>
            <p>남양<span>i</span></p>
            <p><BsFillArrowRightCircleFill/></p>
          </div>
      </div>
      </div>
       <div className='header'>
         
         <div className='headerin'>
          {/* 
          다른 주소로 이동시키기
          <Link to="주소">문자</Link> 
          */}
          <h1 className='logo'><Link to="/"><img src='https://shopping.namyangi.com/resources/images/common/logo.png'/></Link></h1> 
          <ul className='nav'>
            <li><Link to="/component/member" style={{textDecoration:'none'}}>프리미어멤버쉽</Link></li>
            <li><Link to="/component/product" style={{textDecoration:'none'}}>냉장제품</Link></li>
            <li><Link to="/component/market" style={{textDecoration:'none'}}>시크릿마켓</Link></li>
            <li><Link to="/component/brand" style={{textDecoration:'none'}}>브랜드관</Link></li>
            <li><Link to="/component/plan" style={{textDecoration:'none'}}>기획전</Link></li>
            <li><Link to="/component/event" style={{textDecoration:'none'}}>이벤트</Link></li>
            <li><Link to="/component/delivery" style={{textDecoration:'none'}}>가정배달</Link></li>
          </ul>
          <div className='icons'>
            <div><BiSearchAlt/></div>
            <div><BiShoppingBag/></div>
            <div><BiTime/></div>
            <div><BiSmile/></div>
          </div>
         </div>
       </div>
       {/*
        라우터 객체 바뀔 영역
        특정 주소에 컴포넌트 연결하는 방법
        <Route path="주소" component={보여줄 컴포넌트}></Route>
        */}
       <div>
        <Route path="/" exact={true} component={MainPage}></Route>
        <Route path="/component/member" component={Member}></Route>
        <Route path="/component/product" component={Product}></Route>
        <Route path="/component/market" component={Market}></Route>
        <Route path="/component/brand" component={Brand}></Route>
        <Route path="/component/plan" component={Plan}></Route>
        <Route path="/component/event" component={Event}></Route>
        <Route path="/component/delivery" component={Delivery}></Route>
       </div> 
       <div className='footer'>
        
          <div className='footer_t'>
            <div className='footer_t_contents'>
              <h3>공지사항</h3>
              <p>남양몰 5월 연휴 배송 및 고객센터 운영<br/>안내</p>
              <p>2023.04.25</p>
            </div>
            <div className='footer_t_contents'>
              <h3>APP 다운로드</h3>
              <p>내 손안에 남양몰 오픈!<br/>앱스토어, 구글플레이에서 만나요</p>
              <p>다운로드</p>
            </div>
            <div className='footer_t_contents'>
              <h3>고객센터</h3>
              <p>평일 : 오전9시 ~ 오후5시<br/>(점심시간 : 11시30분 ~ 1시)<br/>주말, 공휴일은 1:1문의를 이용해 주세요.</p>
              <h2>1522-0130</h2>
            </div>
            <div className='footer_t_icon'>
              <div>
                <FaHeadset className='icon'/>
                <h3>1:1 문의</h3>
              </div>
              <div>
                <MdQuestionAnswer className='icon'/>
                <h3>자주묻는질문</h3>
              </div>
            </div>
          </div> 
       </div>
       <div className='footer_b_wrap'>
              <div className='footer_b'>
                  <div className='footer_b_contents'>
                    <p>회사소개</p>
                    <p>이용약관</p>
                    <p>개인정보처리방침</p>
                    <p>고객센터</p>
                  </div>
                  <div>
                    <div className='footer_b_input'>
                      <div>
                        <img src="https://shopping.namyangi.com/resources/images/common/logo.png"/>
                        <div>
                          <input type='text'></input>
                          <div><button>이동</button></div>
                        
                        </div>
                        <div className='footer_icons'>
                          <div><BsFacebook/></div>
                          <div><AiFillTwitterCircle/></div>
                          <div><BsInstagram/></div>
                          <div><AiFillYoutube/></div>
                        </div>
                      </div>
                      <div className='text'>
                        <p>대표자 성명 : 이광범개인정보보호책임자 : 신현정사업자등록번호 : 202-81-04367 (사업자정보 확인)통신판매업신고 : 서울강남 00873호<br/>
                        의료기기판매업신고 : 제7693호사업자소재지 : 서울시 강남구 도산대로 240, 1964빌딩 남양유업(주)대표번호 : 02-734-1305팩스번호 : 02-733-6389<br/>
                        이메일 : webmaster@namyangi.com남양몰 대표번호 : 1522-0130남양분유 임신육아교실 02-2010-6476</p>
                        <p>&copy; NAMYANG DAIRY PRODUCTS CO.,LTD. ALL RIGHT RESERVED.<br/>
                        남양아이몰의 정보, 콘텐츠 및 UI등을 상업적 목적으로 전재, 전송, 스크래핑 등 무단 사용할 수 없습니다.</p>
                      </div>
                    </div>
                  </div>
                  <div className='text_icons'>
                          <img src='https://shopping.namyangi.com/resources/images/common/img_certimark_06.gif'/>
                          <img src='https://shopping.namyangi.com/resources/images/common/img_certimark_01.gif'/>
                          <img src='https://shopping.namyangi.com/resources/images/common/img_certimark_03.gif'/>
                          <img src='https://shopping.namyangi.com/resources/images/common/img_certimark_04.gif'/>
                  </div>
              </div>
            </div>
       </TextProvider>
    </div>
  );
}

export default App;
