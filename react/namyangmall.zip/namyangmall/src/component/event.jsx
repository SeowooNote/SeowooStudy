import React from "react";
import styles from "./event.module.css";
import Carousel from 'react-bootstrap/Carousel';
import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';

// 이벤트 결과
function Results({result}){
    return(
        <div className={styles.resultBox}>
            <p>
              <span className={styles.span1}>{result.txt}</span>
              <span className={styles.span2}>{result.date}</span>
            </p>
        </div>
    );
}

// 진행중인 이벤트
function EventIng({event}){
    return(
        <div className={styles.eventIngBox}>
            <img src={event.src} alt={event.txt} />
            <div>
                <h4>{event.txt}</h4>
                <p>{event.date}</p>
            </div>
        </div>
    )
}

// 종료된 이벤트
function EventClosed({event}){
    return(
        <div className={styles.eventIngBox}>
            <img src={event.src} alt={event.txt} />
            <div>
                <h4>{event.txt}</h4>
                <p>{event.date}</p>
            </div>
        </div>
    )
}

function Event(){
    const results = [
        {
            id: 1,
            txt: '[분유리뉴얼퀴즈] 리뉴얼 출시 퀴즈 이벤트 당첨자 발표 안내',
            date: '23.01.06'
        },
        {
            id: 2,
            txt: '[뉴페이스체험단] 리얼 아몬드음료, 아몬드데이 체험단! 우수 리뷰 당첨자 발표',
            date: '22.01.04'
        },
        {
            id: 3,
            txt: '[뉴페이스체험단] 아몬드데이 체험단 우수 리뷰 당첨자 발표',
            date: '22.11.30'
        },
        {
            id: 4,
            txt: '[10월 임산부의 날] 프리미엄 멤버십 어썸한 쇼핑지원 당첨자 발표',
            date: '22.11.11'
        }
    ]

    const eventIng = [
        {
            id: 1,
            src: 'https://shoppingcdn.namyangi.com/attach/item/2023/202304/c59164d0-98b2-49f4-8b82-d6eb920e4868.png',
            txt: '함께하면 대박나는 2023 동행축제',
            date: '기간 23.04.28 ~ 23.05.31'
        },
        {
            id: 2,
            src: 'https://shoppingcdn.namyangi.com/attach/item/2023/202304/f249255d-5634-473f-ab68-afe7a7e86de5.jpg',
            txt: '남양몰 포토리뷰 베스트 리뷰어 이벤트',
            date: '기간 23.04.25 ~ 23.05.31'
        },
        {
            id: 3,
            src: 'https://shoppingcdn.namyangi.com/attach/item/2023/202304/ed5ed4c7-31bf-4367-b797-c71a272dc09e.png',
            txt: '남양몰 APP 다운로드 이벤트',
            date: '기간 23.04.25 ~ 23.05.31'
        },
        {
            id: 4,
            src: 'https://shoppingcdn.namyangi.com/attach/item/2023/202303/0526b315-fb67-4c83-94d5-a4ac1323e570.png',
            txt: '#고물가타파 남양분유 제품코드 등록하고 남양몰 포인트 GET',
            date: '기간 23.03.17 ~ 23.04.30'
        },
        {
            id: 5,
            src: 'https://shoppingcdn.namyangi.com/attach/item/2022/202204/fd7365dc-b5be-45ad-bcb4-e8a5c534ae8c.png',
            txt: '초특가의 신세계, 남양몰 시크릿마켓!',
            date: '기간 22.04.02 ~ 23.12.31'
        }
    ]

    const eventClosed = [
        {
            id: 1,
            src: 'https://shoppingcdn.namyangi.com/attach/item/2023/202304/6ab43aa7-6191-4012-824c-40a3fe9db4b8.png',
            txt: '오직 시크릿마켓에서만, 쉬크릿 0원딜!',
            date: '기간 23.04.19 ~ 23.04.20'
        },
        {
            id: 2,
            src: 'https://shoppingcdn.namyangi.com/attach/item/2023/202304/6ab43aa7-6191-4012-824c-40a3fe9db4b8.png',
            txt: '오직 시크릿마켓에서만, 쉬크릿 0원딜!',
            date: '기간 23.04.06 ~ 23.04.06'
        },
        {
            id: 3,
            src: 'https://shoppingcdn.namyangi.com/attach/item/2023/202304/6ab43aa7-6191-4012-824c-40a3fe9db4b8.png',
            txt: '오직 시크릿마켓에서만, 쉬크릿 0원딜!',
            date: '기간 23.03.23 ~ 23.03.23'
        },
        {
            id: 4,
            src: 'https://shoppingcdn.namyangi.com/attach/item/2023/202304/6ab43aa7-6191-4012-824c-40a3fe9db4b8.png',
            txt: '오직 시크릿마켓에서만, 쉬크릿 0원딜!',
            date: '기간 23.03.09 ~ 23.03.10'
        },
        {
            id: 5,
            src: 'https://shoppingcdn.namyangi.com/attach/item/2023/202304/6ab43aa7-6191-4012-824c-40a3fe9db4b8.png',
            txt: '오직 시크릿마켓에서만, 쉬크릿 0원딜!',
            date: '기간 3.02.22 ~ 23.02.23'
        },
    ]

   return(
    <div>
        <div className={styles.mainimg_wrap}>
            <div className={styles.mainimg}>
                <Carousel className={styles.mainimg_img}>
                    <Carousel.Item className={styles.mainimg_imgbox}>
                        <img
                        // className="d-block w-100"
                        src="https://shoppingcdn.namyangi.com/attach/site/2022/202204/9816f39e-918f-436d-a9f3-ec7cc092c7e5.png"
                        alt="First slide"
                        />
                    </Carousel.Item>
                    <Carousel.Item className={styles.mainimg_imgbox}>
                        <img
                        // className="d-block w-100"
                        src="https://shoppingcdn.namyangi.com/attach/site/2020/202011/bf81c446-5d7d-483f-af35-35060e037325.png"
                        alt="Second slide"
                        />
                    </Carousel.Item>
                    <Carousel.Item className={styles.mainimg_imgbox}>
                        <img
                        // className="d-block w-100"
                        src="https://shoppingcdn.namyangi.com/attach/site/2020/202011/a0262bb6-6047-47ad-a608-1b8bb5604490.png"
                        alt="Third slide"
                        />
                    </Carousel.Item>
                </Carousel>
            </div>
        </div>
        <div className='contents'>
            <div className={styles.contents01}>
                <div className={styles.none}></div>
                <div className={styles.result}>
                    <div className={styles.result_l}>
                        <h3>이벤트 결과</h3>
                        <p>더보기</p>
                    </div>
                    <div className={styles.result_r}>
                        {results.map((result)=>(
                            <Results result={result} key={result.id}/>
                        ))}
                    </div>
                </div>
            </div>
            <div className={styles.contents02} id="event_tab">
                <h3>이벤트</h3>
                <Tabs
                    defaultActiveKey="profile"
                    id="fill-tab-example"
                    className="mb-3"
                    fill
                >
                    <Tab eventKey="home" title="진행중인 이벤트">
                        {eventIng.map((event)=>(
                            <EventIng event={event} key={event.id}/>
                        ))}
                    </Tab>
                    <Tab eventKey="profile" title="종료된 이벤트">
                        {eventClosed.map((event)=>(
                            <EventClosed event={event} key={event.id}/>
                        ))}
                    </Tab>
                </Tabs>
            </div>
        </div>
    </div>
   )
} 

export default Event;