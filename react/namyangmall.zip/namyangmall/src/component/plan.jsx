import React from "react";
//내부로 컴포넌트 생성
//yarn add styled-components
import styled from "styled-components";
import styles from "./plan.module.css";

//내부에서 컴포넌트 생성및 스타일을 내부에서 선언
const PlanItem = styled.div`
/* float:left; */
   margin:15px 0px;
   width:550px;
   height:260px;
   cursor: pointer;
   transition: all 0.5s;
&:hover{
    border:1px solid #ccc;
}   
& > img{
    width: 100%;
    height: 187px;
} 
& > h4{
    margin-top: 20px;
    font-size:16px;
} 
& > p{
    font-size:13px;
}         
`

function Plan(){
   const items = [
    {
      id:1, 
      src:'https://shoppingcdn.namyangi.com/attach/item/2023/202304/6c205439-e307-4d42-abb8-f099a5617735.png', 
      ttl:'루카스나인 리저브 드립스틱 신제품 출시',
      txt:'2023.04.04 ~ 2023.05.31'   
    },
    {
      id:2,
      src:'https://shoppingcdn.namyangi.com/attach/item/2023/202302/7a666558-7a70-499d-9b5d-403d548aa6c4.png', 
      ttl:'분유에 진심을 영양에 과학을_남양 분유 기획전',
      txt:'2023.02.07 ~ 2023.06.30'   
    },
    {
      id:3,  
      src:'https://shoppingcdn.namyangi.com/attach/item/2023/202301/f51165d8-6e0e-4463-bdaa-da6fa933a895.png', 
      ttl:'테이크핏 케어, 9가지 필수 아미노산이 모두 함유된 완전 단백질 플랜',
      txt:'2023.01.30 ~ 2023.06.30'   
    },
    {
      id:4,
      src:'https://shoppingcdn.namyangi.com/attach/item/2022/202211/3d8bd170-f24b-42f7-958f-eee11cfe77f1.png', 
      ttl:'우리아이 성장의 KEY를 찾다 키플러스 (성장기어린이/청소년)',
      txt:'2022.11.02 ~ 2023.06.30'   
    },
    {
      id:5,
      src:'https://shoppingcdn.namyangi.com/attach/item/2022/202211/f95274ad-2da6-4172-8f6e-53bbeb1f6e5b.png', 
      ttl:'국내산 천마로 더 진하고 든든한 천마차 (단호박/콘플레이크)',
      txt:'2022.11.02 ~ 2023.06.30'   
    },
    { 
      id:6, 
      src:'https://shoppingcdn.namyangi.com/attach/item/2022/202210/c8853528-4bbf-47c2-85d4-2a0463b31fca.png',   
      ttl:'든든한 하루의 시작 아몬드데이 (오리지널/온스위트)',
      txt:'2022.10.06 ~ 2023.06.30'   
    }
   ]

   return(
    <div>
        <div className='contents'>
            <div className={styles.contents_h}>
               <h3>남양 기획전</h3>
               <span>총 6건의 기획전이 있습니다.</span>
            </div>
            <div className='contents_in'>
               {
                items.map((item)=>(
                  <PlanItem item={item}>
                    <img src={item.src} alt={item.ttl} />
                    <h4>{item.ttl}</h4>
                    <p>{item.txt}</p>
                  </PlanItem>
                ))
               }
            </div>
        </div>
    </div>
   )
} 

export default Plan;