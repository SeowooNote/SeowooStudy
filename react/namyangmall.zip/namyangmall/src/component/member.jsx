import React from "react";
import styles from "./member.module.css";
import {RiCoupon3Line} from "react-icons/ri";
import {BsGraphUpArrow, BsGift} from "react-icons/bs";


// 첫번째 혜택에 아이템요소
function Benfit01Item({item}){
    return(
        <div className={styles.benefit01Item}>
            <img src={item.src} alt={item.txt}/>
            <p>{item.txt}</p>
        </div>
    );
}

// 두번째 혜택에 아이템요소
function Benfit02Item({text, iconNum}){
    return(
        <div className={styles.benefit02Item}>
            <div>
                {iconNum === "1" && <RiCoupon3Line/>}
                {iconNum === "2" && <BsGraphUpArrow/>}
                {iconNum === "3" && <BsGift/>}
            </div>
            <p>{text}</p>
        </div>
    );
}

function Member(){
    const items = [
        {
            id: 1,
            src: 'https://shoppingcdn.namyangi.com/attach/site/2023/202301/a4bd0376-6ee9-4f5b-8362-0e861b658e32.png?63cc85d',
            txt: '아이엠마더'
        },
        {
            id: 2,
            src: 'https://shoppingcdn.namyangi.com/attach/site/2023/202301/d37c5c9a-0a64-4134-b664-96dc033a1711.png?63cc85d',
            txt: '임페리얼드림XO'
        },
        {
            id: 3,
            src: 'https://shoppingcdn.namyangi.com/attach/site/2023/202301/9a5e35d2-bbdc-489a-a8a5-1b76e9d476f1.png?63cc85d',
            txt: '컴포트케어'
        },
        {
            id: 4,
            src: 'https://shoppingcdn.namyangi.com/attach/site/2023/202301/86f359b4-b022-4b08-a65d-88acf3666940.png?63cc85d',
            txt: '유기농 산양유아식'
        }
    ]

    return(
        <div>
            <div className='mainimg'>
                <div className={styles.mainimg_img}>
                        <div><img src={require('../images/member.png')} alt=""  width="1120px"/></div>
                    </div>
                </div>
            <div className='contents'>
                {/* 혜택1 */}
                <div className={styles.benfit01}>
                    <div className={styles.benfit01_h}>
                        <div className={styles.box}>혜택1</div>
                        <h3>웰컴 기프트로 가입비 돌려받자 !</h3>
                        <p>가입비 내신 만큼 돌려드립니다 (택 1)</p>
                    </div>
                    <div className={styles.benfit01_b}>
                        {items.map((item)=>(
                            <Benfit01Item item={item} key={item.id}/>
                        ))}
                    </div>
                    <div className={styles.benfit01_f}>
                        <p>가입선물은 유료 가입자에 한하여 지급되며 선택한 사은품은 변경 및 교환이 불가합니다</p>
                    </div>
                </div>

                {/* 혜택2 */}
                <div className={styles.benfit02}>
                    <div className={styles.benfit02_h}>
                        <div className={styles.box}>혜택2</div>
                        <h3>구매할수록 더욱 커지는 혜택</h3>
                        <p>구매 단계별 할인 혜택이 적용됩니다</p>
                    </div>
                    <div className={styles.benfit02_b}>
                        <Benfit02Item text='첫 구매부터 15% 할인' iconNum='1'/>
                        <Benfit02Item text='구매 구간별 할인폭 증가' iconNum='2'/>
                        <Benfit02Item text='5회 구매확정 시 마다 사은품 증정' iconNum='3'/>
                    </div>
                    <div className={styles.benfit02_f}>
                        <p>단계별 한 사람이 구매할 수 있는 구매 총량은 한정되어 있으며, 구매량에 관계없이 구매 횟수로 사은품제공 및 할인율이 차등 적용됩니다.</p>
                    </div>
                </div>

                {/* 혜택3 */}
                <div className={styles.benfit03}>
                    <div className={styles.benfit03_h}>
                        <div className={styles.box}>혜택3</div>
                        <h3>프리미엄멤버십 회원 전용관 혜택</h3>
                        <p>구매 단계별 할인 혜택이 제공됩니다</p>
                    </div>
                    <div className={styles.benfit03_b}>
                        <div><img src={require('../images/cafe.png')} alt="" /></div>
                    </div>
                    <div className={styles.benfit03_f}>
                        <button>프리미엄멤버십 전용관 입장</button>
                    </div>
                </div>

                <div className={styles.faq}>
                    <div className={styles.faq_l}>
                        <h3>프리미엄멤버십 FAQ</h3>
                        <p>더보기</p>
                    </div>
                    <div className={styles.faq_r_l}>
                        <p><span>1</span>   프리미엄 멤버십이란 무엇인가요?</p>
                        <p><span>2</span>   프리미엄 멤버십 할인이 적용되는 제품은 어떤 것...</p>
                        <p><span>3</span>   남양유업의 다른 멤버십(다둥이 카드등)혜택과 중...</p>
                    </div>
                    <div className={styles.faq_r_r}>
                        <p><span>4</span>   프리미엄 멤버십에 가입할수 있는 조건은 무엇인...</p>
                        <p><span>5</span>   남양몰의 일반 사은품과 중복 지급되나요? 사은품...</p>
                        <p><span>6</span>   등급별 주문제한 총량은 얼마나 되나요?</p>
                    </div>
                </div>
                <div className={styles.note}>
                    <div className={styles.note_l}>
                        <h4>프리미엄멤버십 가입시 유의사항</h4>
                    </div>
                    <div className={styles.note_r}>
                        <p>프리미엄멤버십 할인구간 적용을 위한 구매 횟수는 프리미엄멤버십 상품 구매횟수만 카운팅됩니다.</p>
                        <p>웰컴기프트는 유로가입자에 한하여 제공해드립니다.</p>
                        <p>프리미엄멤버십 갱신기간은 없으며 탈회 전까지 유지됩니다.</p>
                        <p>프리미엄멤버십(유료가입자) 해지는 고객센터를 통해서만 가능합니다.(1522-0130)</p>
                        <p>프리미엄멤버십 혜택은 당사의 사엊에 따라 변경될 수 있습니다.</p>
                    </div>
                </div>
                <div className={styles.btn_area}>
                    <button>프리미엄멤버쉽 유료가입</button>
                </div>
            </div>
        </div>
    )
} 

export default Member;