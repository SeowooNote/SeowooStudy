import React from "react";
import styles from './brand.module.css';
import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';
import {useTextState} from '../context'

function Item({item}){
    return(
        <div className={styles.p_item}>
        <img src={item.src} alt={item.title} />
        <h4>{item.title}</h4>
        <p>{item.price}</p>
        <span style={{display:item.act? "block" : "none"}}>냉장제품</span>
        </div>
    )
}

function ItemA({item}){
    if(item.type === 'a'){
        return(
            <div className={styles.p_item}>
            <img src={item.src} alt={item.title} />
            <h4>{item.title}</h4>
            <p>{item.price}</p>
            <span style={{display:item.act? "block" : "none"}}>냉장제품</span>
            </div>
        )
    }
}

function ItemB({item}){
    if(item.type === 'b'){
        return(
            <div className={styles.p_item}>
            <img src={item.src} alt={item.title} />
            <h4>{item.title}</h4>
            <p>{item.price}</p>
            <span style={{display:item.act? "block" : "none"}}>냉장제품</span>
            </div>
        )
    }
}

function Brand(){
   const items = useTextState();//외부에 있는 데이터 객체화
   return(
    <div>
        <div className={styles.contents}>
            <div className={styles.tabs} id="brand_tab">
            <Tabs
            defaultActiveKey="home"
            id="uncontrolled-tab-example"
            className="mb-3"
            >
                <Tab eventKey="home" title="분류별">
                    <h3>우유</h3>
                    <div className={styles.tabs_b}>
                    {items.map((item) =>(
                        <ItemA  item={item} key={item.id}/>
                    ))}  
                    </div>
                    <h3>요거트</h3>
                    <div className={styles.tabs_b}>
                    {items.map((item) =>(
                        <ItemB  item={item} key={item.id}/>
                    ))}  
                    </div>
                </Tab>
                <Tab eventKey="profile" title="이름별">
                    <h3>이름별</h3>
                    <div className={styles.tabs_b}>
                    {items.map((item) =>(
                        <Item  item={item} key={item.id} />
                    ))}  
                    </div>
                </Tab>
            </Tabs>
            </div>
        </div>
    </div>
   )
} 

export default Brand;