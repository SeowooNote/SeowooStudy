import React from "react";
import styles from './delivery.module.css';
import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';

// 가정배달 추천제품
function Recommend({recommend}){
    return(
        <div className={styles.recommendBox}>
            <img src={recommend.src} alt={recommend.txt}/>
            <h4>{recommend.txt}</h4>
            <h3>{recommend.price}</h3>
        </div>
    )
}

// 아이를 위한 제품
function ForKids({kids}){
    return(
        <div className={styles.ForKidsBox}>
            <img src={kids.src} alt={kids.txt}/>
            <h4>{kids.txt}</h4>
            <h3>{kids.price}</h3>
        </div>
    )
}

function Delivery(){
    const recommend = [
        {
            id: 1,
            src: 'https://shoppingcdn.namyangi.com/attach/item/2022/202210/09710662-1367-4fdf-b0cc-6f30c6c7f9a6.jpg?63cc85d',
            txt: '[가정배달] 아침의 선물 불가리스 골드 (150ml)',
            price: '1,550원'
        },
        {
            id: 2,
            src: 'https://shoppingcdn.namyangi.com/attach/item/2021/202111/66d0430e-5b53-4578-9b85-1f94eeec969b.jpg?63cc85d',
            txt: '[가정배달] 아침의 선물 (930ml)',
            price: '3,200원'
        },
        {
            id: 3,
            src: 'https://shoppingcdn.namyangi.com/attach/item/2020/202002/768b781f-9c85-421c-9913-847da31686ec.jpg?63cc85d',
            txt: '[가정배달] 아침의 선물 아인슈타인(900ml)',
            price: '3,600원'
        },
        {
            id: 4,
            src: 'https://shoppingcdn.namyangi.com/attach/item/2021/202111/f84d85fa-2711-49d0-96b7-c58a4a824fa1.jpg?63cc85d',
            txt: '[가정배달] 아침의 선물 슈퍼밀크(900ml)',
            price: '3,600원'
        },
        {
            id: 5,
            src: 'https://shoppingcdn.namyangi.com/attach/item/2019/201908/2c94a5f5-135f-4357-a3b5-999f53be5970.jpg?63cc85d',
            txt: '[가정배달] 아침의 선물 고칼슘&글루코사민(900ml)',
            price: '3,600원'
        },
        {
            id: 6,
            src: 'https://shoppingcdn.namyangi.com/attach/item/2020/202004/74b07f79-8da7-422a-be7b-d2559b9d29a0.jpg?63cc85d',
            txt: '[가정배달] 하루근력 (900ml)',
            price: '3,750원'
        },
    ]

    const kids = [
        {
            id: 1,
            src: 'https://shoppingcdn.namyangi.com/attach/item/2019/201908/6b40a997-2daa-43df-802d-524fd0a77b46.jpg?63cc85d',
            txt: '[가정배달] 이오 (80ml)',
            price: '550원'
        },
        {
            id: 2,
            src: 'https://shoppingcdn.namyangi.com/attach/item/2020/202002/312b3b02-aaac-48f7-b0f8-63ff9d3540b4.jpg?63cc85d',
            txt: '[가정배달] 아침의 선물 아인슈타인 베이비(900ml)',
            price: '3,600원'
        },
        {
            id: 3,
            src: 'https://shoppingcdn.namyangi.com/attach/item/2020/202002/6d2173de-954d-4b8b-a62a-db4831e5e772.jpg?63cc85d',
            txt: '[가정배달] 아침의 선물 아인슈타인 키즈(900ml)',
            price: '3,600원'
        }
    ]



   return(
    <div>
        <div className='mainimg'>
            <div className={styles.mainimg_t}>
                <img src="https://shoppingcdn.namyangi.com/attach/site/2021/202111/1d77283d-eb9d-4db0-8609-cbfc6365efab.jpg?63cc85d" alt="" />
            </div>
            <div className={styles.mainimg_b}>
                <img src="https://shoppingcdn.namyangi.com/attach/site/2023/202302/453196af-77e1-4937-b825-ae7399e1300e.jpg?63cc85d" alt="" />
                <img src="https://shoppingcdn.namyangi.com/attach/site/2021/202103/c98937de-e26c-4494-ad4b-bf32337df803.png?63cc85d" alt="" />
            </div>
        </div>
        <div className='contents'>
            <div className={styles.contents1} id="delivery_tab">
                <Tabs
                    defaultActiveKey="profile"
                    id="fill-tab-example"
                    className="mb-3"
                    fill
                >
                <Tab eventKey="home" title="가정배달 추천제품">
                    {recommend.map((recommend)=>(
                        <Recommend recommend={recommend} key={recommend.id}/>
                    ))}
                </Tab>
                <Tab eventKey="profile" title="아이를 위한 제품">
                    {kids.map((kids)=>(
                        <ForKids kids={kids} key={kids.id}/>
                    ))}
                </Tab>
                </Tabs>
            </div>
            <div className={styles.contents2}>
                <div className={styles.contents2_in}>
                    <h3>분류별 상품</h3>
                    <div className={styles.contents2_h}>
                        <h3>베이비,키즈존</h3>
                        <p>더 많은 상품 보기</p>
                    </div>
                    <div className={styles.contents2_b}>
                        <img src="https://shoppingcdn.namyangi.com/attach/item/2019/201908/6b40a997-2daa-43df-802d-524fd0a77b46.jpg?63cc85d" alt="" />
                        <div>
                            <p>[가정배달] 이오 (80ml)</p>
                            <span>550원</span>
                        </div>
                    </div>
                </div>
            </div>
            <div className={styles.contents3}>
                <div className={styles.contents3_in}>
                    <div className={styles.contents3_h}>
                        <h3>가정배달 인기 브랜드</h3>
                        <p>자세히 보기</p>
                    </div>
                    <div className={styles.contents3_b}>
                        <img src="https://shoppingcdn.namyangi.com/attach/site/2019/201908/86f20c61-5b7c-434d-8744-690bca5c3d68.png?63cc85d" alt="" />
                        <h4>아인슈타인</h4>
                        <p>품질검사도 영양성분도 한 수 위!</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
   )
} 

export default Delivery;