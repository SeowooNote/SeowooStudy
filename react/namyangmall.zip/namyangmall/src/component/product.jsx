import React from "react";
import './product.css';
import {useTextState} from '../context'

function Item({item}){
    return(
        <div className="p_item">
           <img src={item.src} alt={item.title} />
           <h4>{item.title}</h4>
           <p>{item.price}</p>
           <span style={{display:item.act? "block" : "none"}}>냉장제품</span>
        </div>
    )
}

function Product(){
   const items = useTextState();//외부에 있는 데이터 객체화

   return(
    <div>
        <div className='contents'>
            <div className='contents_h'>
              <h3>냉장제품</h3>
              <p>총 <span>26</span>개의 상품이 있습니다.</p>
            </div> 
            <div className='product_area'>
              {items.map((item) =>(
                <Item  item={item} key={item.id} />
              ))}          
            </div>   
        </div>
    </div>
   )
} 

export default Product;