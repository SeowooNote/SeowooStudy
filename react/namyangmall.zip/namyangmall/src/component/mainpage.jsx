import React from "react";
import styled from 'styled-components';
import styles from './mainpage.module.css'
import {useTextState} from '../context'
import Carousel from 'react-bootstrap/Carousel';
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import Alert01 from './alert01' 

const FirstProduct = styled.div`
  margin: 0 auto;
  width: 1120px;
  height: 350px;
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
`;
// const Items = styled.div`
//     position: relative;
//     margin:0 0;
//     width: 250px;
//     height: 350px;
//     border:1px solid #000;
//     box-sizing: border-box;
//     img{
//         width: 100%;
//     }
//     h4{
//     margin-top: 10px;
//     padding: 0 10px;
//     font-size: 15px;
//     }
//     p{
//     margin-top: 10px;
//     font-size: 14px;
//     text-align: right;
//     padding: 0 10px;
//     }
//     span{
//     position: absolute;
//     top:10px; left: 10px;
//     z-index: 9999;
//     padding: 5px 12px;
//     background-color: rgb(76, 76, 76);
//     font-size: 10px;
//     color:#fff;
//     border-radius: 2px;
// }

// `

function Item({item}){
    if(item.id < 5){
    return(
        <div className={styles.p_item}>
           <img src={item.src} alt={item.title} />
           <h4>{item.title}</h4>
           <p>{item.price}</p>
           <span style={{display:item.act? "block" : "none"}}>냉장제품</span>
        </div>
    )}
}


function MainPage(){
    const items = useTextState();
   return(
    <div>
        <div className={styles.mainimg_wrap}>
          <div className={styles.mainimg}>
              <Carousel className={styles.mainimg_img}>
                <Carousel.Item className={styles.mainimg_imgbox}>
                  <img
                    // className="d-block w-100"
                    src="https://shoppingcdn.namyangi.com/attach/site/2023/202305/f5b4996a-9307-4fcf-a642-2bdd70054157.png?63cc85d"
                    alt="First slide"
                    />
                  </Carousel.Item>
                  <Carousel.Item className={styles.mainimg_imgbox}>
                    <img
                      // className="d-block w-100"
                      src="https://shoppingcdn.namyangi.com/attach/site/2023/202304/ccbbfa73-13a9-4c0a-ad1e-8124a0a6722f.png?63cc85dg"
                      alt="Second slide"
                    />
                  </Carousel.Item>
                  <Carousel.Item className={styles.mainimg_imgbox}>
                    <img
                      // className="d-block w-100"
                      src="https://shoppingcdn.namyangi.com/attach/site/2023/202304/57af4190-8d98-4212-99bd-ccf9fbb9befa.png?63cc85d"
                      alt="Third slide"
                    />
                  </Carousel.Item>
                  <Carousel.Item className={styles.mainimg_imgbox}>
                    <img
                      // className="d-block w-100"
                      src="https://shoppingcdn.namyangi.com/attach/site/2022/202210/cfa29d23-98e5-4680-9235-d9d650d910a1.png?63cc85d"
                      alt="Third slide"
                    />
                  </Carousel.Item>
                </Carousel>
            </div>
        </div>
        <div className='contents'>
          <div className={styles.tabss}>
            <h3>상품</h3>
          </div>
        <FirstProduct>
          {items.map((item)=>(
            <Item  item={item} key={item.id} />
                    // <Items item={item} key={item.id}>
                    //     <img src={item.src} alt={item.title} />
                    //     <h4>{item.title}</h4>
                    //     <p>{item.price}</p>
                    //     <span style={{display:item.act? "block" : "none"}}>냉장제품</span>
                    // </Items>
          ))}  
        </FirstProduct>

        <div className={styles.tabs}>
          <h3>이벤트 미리보기</h3>
        </div>
        <div className={styles.cardbox}>
          <div>
            <Card style={{ width: '250px' }} className={styles.cardbox_in}>
              <Card.Img variant="top" src="https://shoppingcdn.namyangi.com/attach/item/2023/202304/c59164d0-98b2-49f4-8b82-d6eb920e4868.png" />
              <Card.Body>
                <Card.Title>함께하면 대박나는 2023 동행축제</Card.Title>
                <Card.Text>
                  기간 23.04.28 ~ 23.05.31
                </Card.Text>
                <Button variant="primary">이벤트 보러가기</Button>
              </Card.Body>
            </Card>
          </div>
          <div>
            <Card style={{ width: '250px' }}>
              <Card.Img variant="top" src="https://shoppingcdn.namyangi.com/attach/item/2023/202304/f249255d-5634-473f-ab68-afe7a7e86de5.jpg" />
              <Card.Body>
                <Card.Title>남양몰 포토리뷰 베스트 리뷰어 이벤트</Card.Title>
                <Card.Text>
                  기간 23.04.25 ~ 23.05.31
                </Card.Text>
                <Button variant="primary">이벤트 보러가기</Button>
              </Card.Body>
            </Card>
          </div>
          <div>
            <Card style={{ width: '250px' }}>
              <Card.Img variant="top" src="https://shoppingcdn.namyangi.com/attach/item/2023/202304/ed5ed4c7-31bf-4367-b797-c71a272dc09e.png" />
              <Card.Body>
                <Card.Title>남양몰 APP 다운로드 이벤트</Card.Title>
                <Card.Text>
                  기간 23.04.25 ~ 23.05.31
                </Card.Text>
                <Button variant="primary">이벤트 보러가기</Button>
              </Card.Body>
            </Card>
          </div>
          <div>
          <Card style={{ width: '250px' }}>
            <Card.Img variant="top" src="https://shoppingcdn.namyangi.com/attach/item/2022/202204/fd7365dc-b5be-45ad-bcb4-e8a5c534ae8c.png" />
            <Card.Body>
              <Card.Title>초특가의 신세계, 남양몰 시크릿마켓!</Card.Title>
              <Card.Text>
                기간 23.04.28 ~ 23.12.31
              </Card.Text>
              <Button variant="primary">이벤트 보러가기</Button>
            </Card.Body>
          </Card>
          </div>
        </div>
      </div> 
    </div>
   )
} 

export default MainPage;