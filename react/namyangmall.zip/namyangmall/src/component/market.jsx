import React from "react";
import styles from "./market.module.css";
import {FaGift, FaGifts} from "react-icons/fa";

function Market(){
   return(
    <div>
        <div className='mainimg'>
            <div className={styles.mainimg_box}>
                <div className={styles.market_text}>
                    <h3>웰컴, 여기는 시크릿마켓!</h3>
                    <p>남양몰 특가요원이 알려드리는 오늘의 시크릿코드는?<br/>
                    <span>시크릿코드 : 지지않는특가</span><br/>
                    지금 바로 입력하고 초특가의 세계로!</p>
                </div>
                <div className={styles.market_icon_box}>
                    <FaGift className={styles.market_icon} />
                    <FaGifts className={styles.market_icon}/>

                </div>
            </div>
        </div>
        <div className='contents'>
            <div className={styles.contents_box}>
                <div className={styles.code_text}>
                    <h3>시크릿코드 입력</h3>
                    <p><span>*</span>필수입력 항목</p>
                </div>
                <div className={styles.code_input}>
                    <p><span>*</span>시크릿코드</p>
                    <input type="text" placeholder="시크릿코드를 입력해주세요."/>
                </div>
            </div>
            <div className={styles.btn_area}>
                <button>확인</button>
            </div>
        </div>
        
    </div>
   )
} 

export default Market;