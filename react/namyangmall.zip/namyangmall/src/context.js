import React, { useReducer, createContext, useContext}  from "react";

const products =[
    {
        id: 1,
        type: 'a',
        src: 'https://shoppingcdn.namyangi.com/attach/item/2022/202203/40ecdf28-85fc-4d3a-b831-6e21bb4aee0c.jpg?63cc85d', 
        title: '[냉장]맛있는우유 GT 슈퍼밀크 900mL',
        price: '2,980원',
        act: true
    },
    {
        id: 2,
        type: 'a',
        src: 'https://shoppingcdn.namyangi.com/attach/item/2022/202203/8ab07b7b-97ec-4663-9aa0-b26a0b4171b1.jpg?63cc85d', 
        title: '[냉장]맛있는우유 GT 소화 잘되는 배 안아픈 우유 900mL',
        price: '3,250원',
        act: true
    },
    {
        id: 3,
        type: 'a',
        src: 'https://shoppingcdn.namyangi.com/attach/item/2022/202203/9b0fa8f2-05c0-4f3b-9e9f-7171b27805d2.jpg?63cc85d', 
        title: '[냉장]맛있는우유 GT 깔끔한 저지방 2.3L',
        price: '6,200원',
        act: true
    },
    {
        id: 4,
        type: 'a',
        src: 'https://shoppingcdn.namyangi.com/attach/item/2022/202203/470ee65b-4c87-45a3-85dd-9bcee652585a.jpg?63cc85d', 
        title: '[냉장]맛있는우유 GT 1.8L',
        price: '5,050원',
        act: true
    },
    {
        id: 5,
        type: 'b',
        src: 'https://shoppingcdn.namyangi.com/attach/item/2022/202212/068ce5d3-a68c-48f0-ad13-e13e616b964d.jpg?63cc85d', 
        title: '[냉장]떠먹는 불가리스 복숭아 85g*4입',
        price: '3,000원',
        act: true
    },
    {
        id: 6,
        src: 'https://shoppingcdn.namyangi.com/attach/item/2022/202212/b9219ff1-c0fe-456f-93be-f4361a4d105b.jpg?63cc85d', 
        title: '[냉장]떠먹는 불가리스 딸기 85g*4입',
        price: '3,000원',
        act: true
    },
    {
        id: 7,
        src: 'https://shoppingcdn.namyangi.com/attach/item/2022/202211/e9520296-80fd-4e13-96f0-f957df5ee254.jpg?63cc85d', 
        title: '[냉장]또떠불 하트초코 125g',
        price: '1,400원',
        act: true
    },
    {
        id: 8,
        src: 'https://shoppingcdn.namyangi.com/attach/item/2022/202211/847242a9-329b-4b5c-869d-b3a51d294a2f.jpg?63cc85d', 
        title: '[냉장]또떠불 노꽃초코&그래놀라 125g',
        price: '1,400원',
        act: true
    },
    {
        id: 9,
        src: 'https://shoppingcdn.namyangi.com/attach/item/2021/202105/68f7f57e-4ff6-4b5d-bcc4-333e12563d27.jpg?63cc85d', 
        title: '[냉장]100% 무첨가 불가리스 생요거트 435g',
        price: '2,800원',
        act: true
    },
    {
        id: 10,
        src: 'https://shoppingcdn.namyangi.com/attach/item/2022/202201/51b722f8-1867-4e23-904c-bd0fc06af0ca.jpg?63cc85d', 
        title: '[냉장]이너케어 간 프로텍트 130mL*4입',
        price: '8,980원',
        act: true
    },
    {
        id: 11,
        src: 'https://shoppingcdn.namyangi.com/attach/item/2022/202201/1c130e90-7a70-4304-9c20-ac5d964e18d5.jpg?63cc85d', 
        title: '[냉장]이너케어 위 프로텍트 130mL*4입',
        price: '8,980원',
        act: true
    },
    {
        id: 12,
        src: 'https://shoppingcdn.namyangi.com/attach/item/2022/202201/14185f33-4482-4a13-9e22-0eb32e9dcdcf.jpg?63cc85d', 
        title: '[냉장]이너케어 장 프로텍트 130mL*4입',
        price: '7,980원',
        act: true
    },
    {
        id: 13,
        src: 'https://shoppingcdn.namyangi.com/attach/item/2022/202201/14185f33-4482-4a13-9e22-0eb32e9dcdcf.jpg?63cc85d', 
        title: '[냉장]이너케어 장 프로텍트 130mL*4입',
        price: '7,980원',
        act: true
    },
    {
        id: 14,
        src: 'https://shoppingcdn.namyangi.com/attach/item/2022/202201/14185f33-4482-4a13-9e22-0eb32e9dcdcf.jpg?63cc85d', 
        title: '[냉장]이너케어 장 프로텍트 130mL*4입',
        price: '7,980원',
        act: true
    },
    {
        id: 15,
        src: 'https://shoppingcdn.namyangi.com/attach/item/2022/202201/14185f33-4482-4a13-9e22-0eb32e9dcdcf.jpg?63cc85d', 
        title: '[냉장]이너케어 장 프로텍트 130mL*4입',
        price: '7,980원',
        act: true
    },
    {
        id: 16,
        src: 'https://shoppingcdn.namyangi.com/attach/item/2022/202201/14185f33-4482-4a13-9e22-0eb32e9dcdcf.jpg?63cc85d', 
        title: '[냉장]이너케어 장 프로텍트 130mL*4입',
        price: '7,980원',
        act: true
    },
    {
        id: 17,
        src: 'https://shoppingcdn.namyangi.com/attach/item/2022/202211/59cedff9-760d-4d12-83fb-ddc92c0ba0bf.jpg?63cc85d', 
        title: '[냉장]자연의 시작 불가리스 사과 150mL*4입',
        price: '4,980원',
        act: true
    },
    {
        id: 18,
        src: 'https://shoppingcdn.namyangi.com/attach/item/2022/202211/4683554c-9799-4c49-96ae-142744655db9.jpg?63cc85d', 
        title: '[냉장]자연의 시작 불가리스 프레인 150mL*4입',
        price: '4,980원',
        act: true
    },
    {
        id: 19,
        src: 'https://shoppingcdn.namyangi.com/attach/item/2022/202211/df0b4a73-ff75-4bbe-86e2-1b0947ef4567.jpg?63cc85d', 
        title: '[냉장]위쎈 오리지날 150mL*4입',
        price: '4,000원',
        act: true
    },
    {
        id: 20,
        src: 'https://shoppingcdn.namyangi.com/attach/item/2022/202207/a58d1b7f-fbe9-4045-b24e-9707347f5feb.jpg?63cc85d', 
        title: '[냉장]위쎈 샤인머스캣 150mL*4입',
        price: '4,000원',
        act: true
    },
    {
        id: 21,
        src: 'https://shoppingcdn.namyangi.com/attach/item/2022/202203/b018a2f2-2ff8-417f-b496-6bdd48cac92f.jpg?63cc85d', 
        title: '[냉장]이오 80mL*5입',
        price: '2,500원',
        act: true
    },
    {
        id: 22,
        src: 'https://shoppingcdn.namyangi.com/attach/item/2020/202012/d4be4d72-1de4-4e9d-9026-f3d34e936145.jpg?63cc85d', 
        title: '[냉장]남양 요구루트 65mL*20입',
        price: '2,500원',
        act: true
    },
    {
        id: 23,
        src: 'https://shoppingcdn.namyangi.com/attach/item/2023/202304/bdfdc06b-4917-4814-94ac-6ec4c35e2608.jpg?63cc85d', 
        title: '[냉장]떠먹는 불가리스 청귤 85g*4입',
        price: '3,500원',
        act: true
    },
    {
        id: 24,
        src: 'https://shoppingcdn.namyangi.com/attach/item/2023/202304/2bff8f17-e41f-43f0-a174-e1f9745d0883.jpg?63cc85d', 
        title: '[냉장]떠먹는 불가리스 블루베리 85g*4입',
        price: '3,500원',
        act: true
    },
];

function stateReducer(){

}

const StateContext = createContext()

export function TextProvider({children}){
     const [state , dispatch] =useReducer(stateReducer, products)

    return(
        <div>
             <StateContext.Provider value={state} >
               {children}
             </StateContext.Provider> 
        </div>
    )
}

export function useTextState(){
    const context = useContext(StateContext);
    if(!context){
        throw new Error('TodoProvider를 찾을 수 없음');
    }
    return context;
}